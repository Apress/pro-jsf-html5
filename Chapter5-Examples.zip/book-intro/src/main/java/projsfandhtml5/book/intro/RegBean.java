package projsfandhtml5.book.intro;

import javax.enterprise.context.Conversation;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean
@RequestScoped
public class RegBean {

    /**
     * Creates a new instance of RegBean
     */
    public RegBean() {
        Conversation c;
        
        c.
    }
}
