package com.jsfprohtml5.weather.model;

public class UserExistsException extends Exception {
}
