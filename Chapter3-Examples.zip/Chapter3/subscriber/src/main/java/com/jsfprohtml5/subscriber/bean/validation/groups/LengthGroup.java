package com.jsfprohtml5.subscriber.bean.validation.groups;

public interface LengthGroup {
}
